const Joi = require('joi');
const express = require('express');
const ejs = require('ejs');
const fs = require('fs');
const multer = require('multer');

const app = express();

/////uploading picture
app.set('view engine', 'ejs');

var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    var dir = "./uploads";

    if (!fs.existsSync(dir))
    {
      fs.mkdirSync(dir);
    }
    callback(null, dir);

  },

 filename: function (req, file, callback) {
   callback(null, file.originalname);
 }
});

var upload = multer({storage:storage}).array('files',3);

app.post("/upload", (req,res,next) => {
  upload(req,res,function (err) {
  
  if(err){
    res.send('something gone wrong');

  }
  res.send('upload complete');
});
});

app.get("/upload", (req, res) => {
  res.render('index');
})

//////////////////////
app.use(express.json());

const courses = [
{id: 1, name: 'course1', des: 'wertyuui', status: 'completed'},
{id: 2, name: 'course2', des: 'wertyuui', status: 'pending'},
{id: 3, name: 'course3', des: 'wertyuui', status: 'completed' },
{id: 4, name: 'course4', des: 'wertyuui', status: 'pending' },
{id: 5, name: 'course5', des: 'wertyuui', status: 'pending' }
];

///GET
app.get('/', (req,res) =>{
   res.send('hello world ')
});

app.get('/api/courses', (req,res) =>{
  res.send(courses);
});

app.get('/api/courses/:id', (req,res) =>{

  let course =  courses.find(c => c.id === parseInt(req.params.id));
 
  if(!course) res.status(404).send('The course not found');
  res.send(course);
 });


///POST
app.post('/api/courses', (req, res) => {
  
if( !req.body.name) {
  res.status(400).send('name is req');
  return;

}
if(req.body.name.length < 3) {
  res.status(400).send('name should be greater than 3 letters');
  return;

}

if(!req.body.status) {
  res.status(400).send('status is required');
  return;

}
if(!req.body.des) {
  res.status(400).send('destination is required');
  return;

}

  const course = {
    id: courses.length +1,
    name: req.body.name,
    des: req.body.des,
    status: req.body.status
  };
  courses.push(course);
  res.send(course);
});

////PUT
app.put('/api/courses/:id', (req,res) =>{
  ///loook for the coursename
  const course = courses.find(c => c.id === parseInt(req.params.id));
  ///doesn exit then return 404
  if (!course) res.status(404).send('course was not found')
  course.name = req.body.name;
  res.send(course);
});

///DELETE
app.delete('/api/courses/:id', (req,res) =>{
  ///loook for the coursename
  const course = courses.find(c => c.id === parseInt(req.params.id));
  ///doesn exit then return 404
  if (!course) res.status(404).send('course was not found')
  //delete
 const index =  courses.indexOf(course);
 courses.splice(index, 1);
 res.send(course);
});


////About AND CONTACT WEB PAGE

//var fs = require('fs');
//const { constants } = require('buffer');
//const Joi = require('joi');

app.get('/index', function(req, rep) {
  rep.sendFile(__dirname + '/index.html');
})

app.get('/about', function(req, rep) {
  rep.sendFile(__dirname + '/about.html');
})


app.get('/contact', function(req, rep) {
  rep.sendFile(__dirname + '/contact.html');
})

////DISPLAY ALL USERS FROM INDEX.JSON FILE
app.get('/getUsers', function(req, res) {
  fs.readFile(__dirname + '/users.json', 'utf8', function(err, data){
console.log(data);
res.end(data);

  });
})


app.listen(3000, function() {
    console.log('our server is live on port 3000');
})